// File export_test exports some methods for better testing.

package pgconn
